<?php
    require_once("cabecalho.php");
?>
    <h1>Categorias</h1>
<?php
    require_once("reodape.php");
?>